#undefine EPSINF
#undefine RAY
#undefine BIGENDIAN
#undefine MAGNETOFRICTION
#undefine BOUNDARYDRIVER
#undefine EVOLVINGBOUNDARY
