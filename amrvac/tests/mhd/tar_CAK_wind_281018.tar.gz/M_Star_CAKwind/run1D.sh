#!/bin/bash
setup.pl -phys=mhd -d=1 -arch=intel
