setupt.pl -phys=mhd -d=2 -arch=intel
